@echo off
title JARVIS EXE Builder
echo Sborka avtonomnogo jarvis.exe dlya Windows...
pip install pyinstaller pyttsx3 psutil
pyinstaller --onefile --name "jarvis" jarvis_bridge.py
echo.
echo [Gotovo!] Fayl jarvis.exe sozdan v papke dist/
pause
