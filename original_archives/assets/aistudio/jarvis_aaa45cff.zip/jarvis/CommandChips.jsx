import React from 'react';
import { Send, Headphones, CloudSun, ListChecks } from 'lucide-react';
import { cn } from '@/lib/utils';

const CHIPS = [
  { icon: Send, text: '«Джарвис, открой Телеграм»', command: 'джарвис открой телеграм', primary: true },
  { icon: Headphones, text: '«Открой YouTube»', command: 'открой youtube', primary: false },
  { icon: CloudSun, text: '«Открой погоду»', command: 'открой погоду', primary: false },
  { icon: ListChecks, text: '«Который час»', command: 'который час', primary: false },
];

/** Быстрые подсказки команд — нажатие выполняет ту же команду, что и голосом. */
export default function CommandChips({ onRun }) {
  return (
    <div className="mt-8 flex max-w-3xl flex-wrap items-center justify-center gap-2 px-4">
      {CHIPS.map(({ icon: Icon, text, command, primary }) => (
        <button
          key={command}
          type="button"
          onClick={() => onRun(command)}
          className={cn(
            'group flex items-center gap-2 rounded-full px-4 py-2 text-sm transition-all duration-200',
            primary
              ? 'bg-hud-surface-high/60 text-hud-text hover:bg-hud-accent hover:text-hud-void'
              : 'bg-hud-surface-low/70 text-hud-muted hover:bg-hud-surface-high hover:text-hud-text',
          )}
        >
          <Icon
            className={cn(
              'h-4 w-4 transition-colors',
              primary ? 'text-hud-accent group-hover:text-hud-void' : 'text-hud-dim group-hover:text-hud-accent',
            )}
          />
          {text}
        </button>
      ))}
    </div>
  );
}