import React from 'react';
import { cn } from '@/lib/utils';

const PILL = {
  off: { label: 'СИСТЕМА ВЫКЛЮЧЕНА', dot: 'bg-hud-dim' },
  idle: { label: 'ГОТОВ К ДИАЛОГУ', dot: 'bg-hud-accent shadow-[0_0_8px_#38bdf8]' },
  active: { label: 'СЛУШАЮ', dot: 'bg-hud-accent shadow-[0_0_8px_#38bdf8]' },
  busy: { label: 'ВЫПОЛНЯЮ', dot: 'bg-hud-secondary shadow-[0_0_8px_#60a5fa]' },
};

const ENGINE = { off: 'ОТКЛЮЧЕНО', idle: 'ОЖИДАНИЕ', active: 'ДИАЛОГ', busy: 'РАБОТА' };

export default function TelemetryBar({ phase = 'off', listening }) {
  const pill = PILL[phase] || PILL.off;

  return (
    <div className="mx-auto flex w-full max-w-[1500px] items-start justify-between gap-4 px-6 pt-6 text-[10px] uppercase tracking-[0.14em] lg:px-10">
      <div className="flex flex-col gap-1">
        <div className={cn('flex items-center gap-2 font-medium', listening ? 'text-hud-accent' : 'text-hud-muted')}>
          <span className={cn('h-1.5 w-1.5 rounded-full', listening ? 'animate-ping bg-hud-accent' : 'bg-hud-dim')} />
          {listening ? 'НЕЙРОСВЯЗЬ АКТИВНА' : 'НЕЙРОСВЯЗЬ ОТКЛЮЧЕНА'}
        </div>
        <div className="text-hud-dim">ДВИЖОК v1.0 • {ENGINE[phase] || ENGINE.off}</div>
      </div>

      <div className="flex items-center gap-2.5 rounded-full bg-hud-surface-low/60 px-4 py-1.5 text-hud-text backdrop-blur-xl">
        <span className={cn('h-2 w-2 rounded-full transition-colors', pill.dot)} />
        <span className="font-medium tracking-[0.16em]">{pill.label}</span>
      </div>

      <div className="flex flex-col items-end gap-1">
        <div className="flex items-center gap-2">
          <span>РАСПОЗНАВАНИЕ</span>
          <span className="font-mono font-semibold text-hud-text">ru-RU</span>
        </div>
        <div className="text-hud-dim">ВЕБ-РЕЧЬ • СИНТЕЗ ГОЛОСА</div>
      </div>
    </div>
  );
}