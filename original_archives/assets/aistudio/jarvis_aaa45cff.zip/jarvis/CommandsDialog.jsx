import React, { useState } from 'react';
import { Plus, Terminal, Trash2 } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { cn } from '@/lib/utils';

const FIELD = 'border-hud-text/10 bg-hud-text/5 text-hud-text placeholder:text-hud-dim focus-visible:ring-hud-accent/40';

export default function CommandsDialog({ open, onOpenChange, commands = [], onAdd, onDelete }) {
  const [phrase, setPhrase] = useState('');
  const [url, setUrl] = useState('');
  const [saving, setSaving] = useState(false);

  const empty = !phrase.trim() || !url.trim();

  const submit = async (event) => {
    event.preventDefault();
    if (empty) return;
    setSaving(true);
    try {
      await onAdd({ phrase: phrase.trim(), url: url.trim() });
      setPhrase('');
      setUrl('');
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl border-hud-text/10 bg-hud-surface/95 text-hud-text backdrop-blur-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2.5 text-sm font-medium uppercase tracking-[0.18em] text-hud-text">
            <Terminal className="h-4 w-4 text-hud-accent" />
            Команды Джарвиса
          </DialogTitle>
          <DialogDescription className="text-sm text-hud-muted/80">
            Скажите «Джарвис», затем фразу команды. Для одной ссылки можно перечислить несколько вариантов
            фразы через запятую.
          </DialogDescription>
        </DialogHeader>

        <form
          onSubmit={submit}
          className="grid gap-3 border-b border-hud-text/8 pb-5 sm:grid-cols-[1.4fr_1fr_auto] sm:items-end"
        >
          <div className="space-y-1.5">
            <Label htmlFor="command-phrase" className="text-[10px] uppercase tracking-[0.18em] text-hud-muted">
              Фраза
            </Label>
            <Input
              id="command-phrase"
              value={phrase}
              onChange={(event) => setPhrase(event.target.value)}
              placeholder="открой телеграм, телега"
              className={FIELD}
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="command-url" className="text-[10px] uppercase tracking-[0.18em] text-hud-muted">
              Ссылка
            </Label>
            <Input
              id="command-url"
              value={url}
              onChange={(event) => setUrl(event.target.value)}
              placeholder="web.telegram.org"
              className={FIELD}
            />
          </div>
          <button
            type="submit"
            disabled={saving || empty}
            className={cn(
              'flex h-10 items-center justify-center gap-2 rounded-full border border-hud-accent/40 bg-hud-accent/10 px-5 text-[11px] font-medium uppercase tracking-[0.16em] text-hud-accent-dim transition-colors hover:bg-hud-accent/20',
              (saving || empty) && 'cursor-not-allowed opacity-40 hover:bg-hud-accent/10',
            )}
          >
            <Plus className="h-4 w-4" />
            Добавить
          </button>
        </form>

        <ul className="max-h-[46vh] space-y-2 overflow-y-auto pr-1">
          {commands.map((command) => (
            <li
              key={command.id}
              className="flex items-center justify-between gap-4 rounded-xl border border-hud-text/8 bg-hud-text/3 px-3 py-2.5"
            >
              <div className="min-w-0">
                <div className="truncate text-sm text-hud-text">{command.phrase}</div>
                <div className="truncate font-mono text-[11px] text-hud-dim">{command.url}</div>
              </div>
              <div className="flex shrink-0 items-center gap-3">
                <span className="hidden text-[10px] uppercase tracking-[0.16em] text-hud-dim sm:inline">
                  {command.kind === 'builtin' ? 'встроенная' : 'своя'}
                </span>
                <button
                  type="button"
                  onClick={() => onDelete(command)}
                  aria-label={`Удалить команду ${command.phrase}`}
                  className="rounded-full p-2 text-hud-dim transition-colors hover:bg-hud-error/10 hover:text-hud-error"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            </li>
          ))}
        </ul>
      </DialogContent>
    </Dialog>
  );
}