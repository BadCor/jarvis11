import React, { useEffect, useRef } from 'react';
import { cn } from '@/lib/utils';

const INTENSITY = { off: 0.02, idle: 0.1, active: 0.62, busy: 0.8 };
const POINT_COUNT = 300;
const RINGS = ['80%', '100%', '120%'];

function buildSphere() {
  const points = [];
  const phi = Math.PI * (3 - Math.sqrt(5));
  for (let i = 0; i < POINT_COUNT; i += 1) {
    const y = 1 - (i / (POINT_COUNT - 1)) * 2;
    const ring = Math.sqrt(Math.max(0, 1 - y * y));
    const theta = phi * i;
    points.push({ x: Math.cos(theta) * ring, y, z: Math.sin(theta) * ring });
  }
  return points;
}

/** Сфера-ядро из частиц: вращается, мягко пульсирует в ожидании и вспыхивает голубым при диалоге. */
export default function VoiceOrb({ phase = 'off', onClick, label = 'Включить или выключить прослушивание' }) {
  const canvasRef = useRef(null);
  const phaseRef = useRef(phase);
  const pointsRef = useRef(null);
  if (!pointsRef.current) pointsRef.current = buildSphere();

  useEffect(() => { phaseRef.current = phase; }, [phase]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return undefined;
    const ctx = canvas.getContext('2d');
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const points = pointsRef.current;
    let w = 0;
    let h = 0;
    let raf = 0;
    let intensity = INTENSITY.off;
    let rotationY = 0;

    const resize = () => {
      const rect = canvas.getBoundingClientRect();
      w = rect.width;
      h = rect.height;
      canvas.width = Math.max(1, Math.round(w * dpr));
      canvas.height = Math.max(1, Math.round(h * dpr));
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    resize();
    window.addEventListener('resize', resize);

    const draw = () => {
      const current = phaseRef.current;
      const active = current === 'active' || current === 'busy';
      intensity += ((INTENSITY[current] ?? INTENSITY.off) - intensity) * 0.06;

      const time = Date.now();
      rotationY += 0.0035 * (1 + intensity);
      const rotationX = 0.2 + Math.sin(time * 0.001) * 0.1;
      const base = Math.min(w, h) * 0.28;
      const radius = base * (1 + (active
        ? Math.sin(time * 0.006) * 0.03 + intensity * 0.1
        : Math.sin(time * 0.002) * 0.02));
      const fov = Math.min(w, h) * 0.68;
      const cx = w / 2;
      const cy = h / 2;

      ctx.clearRect(0, 0, w, h);

      // Глухая чёрная подложка под сферой — частицы читаются даже поверх свечения.
      const veilRadius = Math.min(w, h) * 0.5;
      const veil = ctx.createRadialGradient(cx, cy, 0, cx, cy, veilRadius);
      veil.addColorStop(0, 'rgba(0, 0, 0, 0.95)');
      veil.addColorStop(0.6, 'rgba(0, 0, 0, 0.75)');
      veil.addColorStop(1, 'rgba(0, 0, 0, 0)');
      ctx.fillStyle = veil;
      ctx.beginPath();
      ctx.arc(cx, cy, veilRadius, 0, Math.PI * 2);
      ctx.fill();

      const cosY = Math.cos(rotationY);
      const sinY = Math.sin(rotationY);
      const cosX = Math.cos(rotationX);
      const sinX = Math.sin(rotationX);

      const projected = [];
      for (let i = 0; i < points.length; i += 1) {
        const point = points[i];
        const x1 = point.x * cosY - point.z * sinY;
        const z1 = point.z * cosY + point.x * sinY;
        const y1 = point.y * cosX - z1 * sinX;
        const z2 = z1 * cosX + point.y * sinX;
        const scale = fov / (fov + z2 * radius);
        projected.push({
          x: cx + x1 * radius * scale,
          y: cy + y1 * radius * scale,
          z: z2,
          alpha: Math.max(0.3, (z2 + 1) / 2),
          scale,
        });
      }
      projected.sort((a, b) => a.z - b.z);

      // связи между ближайшими частицами — созвездие
      for (let i = 0; i < projected.length; i += 2) {
        for (let j = i + 1; j < Math.min(i + 7, projected.length); j += 1) {
          const dx = projected[i].x - projected[j].x;
          const dy = projected[i].y - projected[j].y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          if (dist < 34) {
            const alpha = (1 - dist / 34) * 0.28 * projected[i].alpha;
            ctx.beginPath();
            ctx.strokeStyle = active
              ? `rgba(56, 189, 248, ${alpha * 1.7})`
              : `rgba(142, 213, 255, ${alpha * 0.8})`;
            ctx.lineWidth = 0.7;
            ctx.moveTo(projected[i].x, projected[i].y);
            ctx.lineTo(projected[j].x, projected[j].y);
            ctx.stroke();
          }
        }
      }

      // частицы
      for (let i = 0; i < projected.length; i += 1) {
        const point = projected[i];
        ctx.beginPath();
        ctx.arc(point.x, point.y, Math.max(1, point.scale * (active ? 2.1 : 1.5)), 0, Math.PI * 2);
        if (active) {
          ctx.fillStyle = `rgba(96, 205, 255, ${point.alpha})`;
          ctx.shadowColor = 'rgba(56, 189, 248, 0.95)';
          ctx.shadowBlur = 10;
        } else {
          ctx.fillStyle = `rgba(196, 226, 255, ${point.alpha})`;
          ctx.shadowColor = 'rgba(142, 213, 255, 0.9)';
          ctx.shadowBlur = 7;
        }
        ctx.fill();
      }
      ctx.shadowBlur = 0;

      raf = requestAnimationFrame(draw);
    };

    raf = requestAnimationFrame(draw);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener('resize', resize);
    };
  }, []);

  const active = phase === 'active' || phase === 'busy';

  return (
    <div className="relative flex items-center justify-center">
      <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
        {RINGS.map((size, i) => (
          <span
            key={size}
            className={cn(
              'absolute rounded-full border border-hud-accent/20 transition-opacity duration-700',
              active ? 'opacity-70' : 'opacity-0',
            )}
            style={{
              width: size,
              height: size,
              animation: active ? `hud-ring 4.5s ease-out ${i * 1.4}s infinite` : 'none',
            }}
          />
        ))}
      </div>

      <button
        type="button"
        onClick={onClick}
        aria-label={label}
        className="group relative flex h-[330px] w-[330px] cursor-pointer items-center justify-center sm:h-[430px] sm:w-[430px]"
      >
        <span
          className={cn(
            'pointer-events-none absolute h-44 w-44 rounded-full blur-2xl transition-all duration-500 group-hover:scale-125',
            active ? 'scale-110 bg-hud-accent/25' : 'bg-hud-accent/15 group-hover:bg-hud-accent/25',
          )}
        />
        <canvas
          ref={canvasRef}
          className="relative z-10 h-full w-full transition-transform duration-500 ease-out group-hover:scale-105"
        />
      </button>
    </div>
  );
}