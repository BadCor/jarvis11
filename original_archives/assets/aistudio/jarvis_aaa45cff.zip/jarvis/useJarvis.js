import { useCallback, useEffect, useRef, useState } from 'react';
import { VERB_RE, findCommand, mainLabel, matchWake, normalize, replyFor } from '@/lib/voice';
import { CLIP_SETS, clipForUrl, playVoiceClip, stopVoiceClip } from '@/lib/voiceClips';

const ACTIVE_TIMEOUT = 12000;
const RESTART_DELAY = 260;
const RESUME_DELAY = 220;

function pickRussianVoice(list) {
  const voices = Array.isArray(list) ? list : [];
  return (
    voices.find((voice) => (voice.lang || '').toLowerCase().startsWith('ru-ru'))
    || voices.find((voice) => (voice.lang || '').toLowerCase().startsWith('ru'))
    || null
  );
}

/**
 * Ядро Джарвиса: постоянное прослушивание, слово-активатор, разбор команды,
 * голосовой ответ и открытие ссылок.
 */
export default function useJarvis({ commands = [], onEvent } = {}) {
  const supported = typeof window !== 'undefined' && !!(window.SpeechRecognition || window.webkitSpeechRecognition);
  const [listening, setListening] = useState(false);
  const [phase, setPhase] = useState('off');
  const [heard, setHeard] = useState('');
  const [response, setResponse] = useState('');
  const [error, setError] = useState('');
  const [blocked, setBlocked] = useState(null);

  const recRef = useRef(null);
  const runningRef = useRef(false);
  const suspendedRef = useRef(false);
  const phaseRef = useRef('off');
  const cmdsRef = useRef(commands);
  const eventRef = useRef(onEvent);
  const timerRef = useRef(null);
  const lastRef = useRef({ text: '', at: 0 });
  const voicesRef = useRef([]);
  const apiRef = useRef({});

  useEffect(() => { cmdsRef.current = commands; }, [commands]);
  useEffect(() => { eventRef.current = onEvent; }, [onEvent]);

  useEffect(() => {
    if (!supported) return undefined;
    const synth = window.speechSynthesis;
    if (!synth) return undefined;
    const load = () => { voicesRef.current = synth.getVoices() || []; };
    load();
    synth.addEventListener?.('voiceschanged', load);
    return () => synth.removeEventListener?.('voiceschanged', load);
  }, [supported]);

  useEffect(() => () => {
    runningRef.current = false;
    clearTimeout(timerRef.current);
    stopVoiceClip();
    try { window.speechSynthesis?.cancel(); } catch (e) { /* noop */ }
    try { recRef.current?.abort(); } catch (e) { /* noop */ }
  }, []);

  const setPhaseSafe = useCallback((next) => {
    phaseRef.current = next;
    setPhase(next);
  }, []);

  const clearTimer = useCallback(() => {
    if (timerRef.current) {
      clearTimeout(timerRef.current);
      timerRef.current = null;
    }
  }, []);

  const emit = useCallback((event) => {
    try { eventRef.current?.(event); } catch (e) { /* noop */ }
  }, []);

  const say = useCallback((text, options = {}) => {
    const { onDone, resume = true, clip } = options;
    setResponse(text);
    emit({ who: 'jarvis', text });
    suspendedRef.current = true;
    try { recRef.current?.abort(); } catch (e) { /* noop */ }
    try { window.speechSynthesis?.cancel(); } catch (e) { /* noop */ }
    stopVoiceClip();

    const finish = () => {
      if (resume && runningRef.current) {
        suspendedRef.current = false;
        setTimeout(() => {
          if (runningRef.current && !suspendedRef.current) {
            try { recRef.current?.start(); } catch (e) { /* noop */ }
          }
        }, RESUME_DELAY);
      }
      onDone?.();
    };

    // Синтезатор остаётся только для фраз, которых нет в записи (время, дата, подсказки).
    const speak = () => {
      const synth = window.speechSynthesis;
      if (!synth || typeof SpeechSynthesisUtterance === 'undefined') {
        finish();
        return;
      }
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = 'ru-RU';
      utterance.rate = 1.03;
      utterance.pitch = 0.85;
      utterance.volume = 1;
      const voice = pickRussianVoice(voicesRef.current.length ? voicesRef.current : synth.getVoices());
      if (voice) utterance.voice = voice;

      let finished = false;
      const done = () => {
        if (finished) return;
        finished = true;
        finish();
      };

      utterance.onend = done;
      utterance.onerror = done;
      setTimeout(() => { if (!finished && !synth.speaking) done(); }, Math.max(4000, text.length * 220));
      try { synth.speak(utterance); } catch (e) { done(); }
    };

    if (clip) {
      playVoiceClip(clip).then((played) => (played ? finish() : speak()));
      return;
    }
    speak();
  }, [emit]);

  const armActive = useCallback(() => {
    clearTimer();
    timerRef.current = setTimeout(() => {
      if (phaseRef.current === 'active') setPhaseSafe('idle');
    }, ACTIVE_TIMEOUT);
  }, [clearTimer, setPhaseSafe]);

  const openUrl = useCallback((url, label) => {
    let opened = null;
    try { opened = window.open(url, '_blank'); } catch (e) { opened = null; }
    if (opened) {
      try { opened.focus(); } catch (e) { /* noop */ }
      emit({ who: 'system', text: `Открыт ${label}` });
    } else {
      setBlocked({ url, label });
      emit({ who: 'system', text: `Браузер заблокировал вкладку для «${label}»` });
    }
  }, [emit]);

  const stop = useCallback((options = {}) => {
    const { keepSpeech = false } = options;
    runningRef.current = false;
    suspendedRef.current = true;
    clearTimer();
    if (!keepSpeech) {
      try { window.speechSynthesis?.cancel(); } catch (e) { /* noop */ }
      stopVoiceClip();
    }
    try { recRef.current?.abort(); } catch (e) { /* noop */ }
    recRef.current = null;
    setListening(false);
    setPhaseSafe('off');
    setHeard('');
    setBlocked(null);
    emit({ who: 'system', text: 'Система отключена' });
  }, [clearTimer, emit, setPhaseSafe]);

  const execute = useCallback((rawText) => {
    const text = normalize(rawText);
    if (!text) return;
    const command = findCommand(text, cmdsRef.current);
    if (!command) {
      if (runningRef.current) {
        setPhaseSafe('active');
        armActive();
      }
      say('Не понял команду, сэр. Скажите, например: открой YouTube.');
      return;
    }
    clearTimer();
    if (command.url) {
      const label = mainLabel(command.phrase);
      setPhaseSafe('busy');
      say(`Открываю ${label}`, {
        clip: clipForUrl(command.url) || CLIP_SETS.done,
        onDone: () => {
          openUrl(command.url, label);
          setPhaseSafe(runningRef.current ? 'idle' : 'off');
        },
      });
      return;
    }
    if (command.action === 'stop') {
      setPhaseSafe('busy');
      say('Отключаюсь, сэр', { clip: CLIP_SETS.bye, resume: false, onDone: () => stop({ keepSpeech: true }) });
      return;
    }
    setPhaseSafe('busy');
    const actionClips = { status: CLIP_SETS.mood, thanks: CLIP_SETS.thanks };
    say(replyFor(command.action), {
      clip: actionClips[command.action],
      onDone: () => setPhaseSafe(runningRef.current ? 'idle' : 'off'),
    });
  }, [armActive, clearTimer, openUrl, say, setPhaseSafe, stop]);

  const handlePhrase = useCallback((raw) => {
    const text = normalize(raw);
    if (!text) return;
    const now = Date.now();
    if (lastRef.current.text === text && now - lastRef.current.at < 2500) return;
    lastRef.current = { text, at: now };
    if (phaseRef.current === 'busy') return;

    if (phaseRef.current === 'active') {
      const wake = matchWake(text);
      const commandText = wake ? [wake.before, wake.rest].filter(Boolean).join(' ').trim() : text;
      emit({ who: 'user', text });
      if (!commandText || !commandText.replace(VERB_RE, '').trim()) {
        armActive();
        say('Слушаю вас, сэр.', { clip: CLIP_SETS.wake });
        return;
      }
      execute(commandText);
      return;
    }

    const wake = matchWake(text);
    if (!wake) return;
    emit({ who: 'user', text });
    if (wake.rest && wake.rest.replace(VERB_RE, '').trim()) {
      execute(wake.rest);
      return;
    }
    setPhaseSafe('active');
    armActive();
    say('Да, сэр', { clip: CLIP_SETS.wake });
  }, [armActive, emit, execute, say, setPhaseSafe]);

  apiRef.current = { handlePhrase, stop };

  const buildRecognition = () => {
    const Recognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    const recognition = new Recognition();
    recognition.lang = 'ru-RU';
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.maxAlternatives = 1;

    recognition.onresult = (event) => {
      let finalText = '';
      let interim = '';
      for (let i = event.resultIndex; i < event.results.length; i += 1) {
        const result = event.results[i];
        const chunk = result[0]?.transcript || '';
        if (result.isFinal) finalText += chunk;
        else interim += chunk;
      }
      if (interim.trim()) setHeard(interim.trim());
      const final = finalText.trim();
      if (final) {
        setHeard(final);
        apiRef.current.handlePhrase?.(final);
      }
    };

    recognition.onerror = (event) => {
      const code = event?.error;
      if (code === 'no-speech' || code === 'aborted') return;
      if (code === 'not-allowed' || code === 'service-not-allowed') {
        setError('Нет доступа к микрофону. Разрешите доступ в настройках браузера.');
        apiRef.current.stop?.();
        return;
      }
      if (code === 'audio-capture') {
        setError('Микрофон не найден.');
        apiRef.current.stop?.();
        return;
      }
      if (code === 'network') setError('Потеряна связь с сервисом распознавания речи.');
    };

    recognition.onend = () => {
      if (!runningRef.current || suspendedRef.current) return;
      setTimeout(() => {
        if (runningRef.current && !suspendedRef.current) {
          try { recognition.start(); } catch (e) { /* noop */ }
        }
      }, RESTART_DELAY);
    };

    recRef.current = recognition;
    return recognition;
  };

  const start = useCallback(async () => {
    setError('');
    if (!supported) {
      setError('Этот браузер не поддерживает распознавание речи. Откройте приложение в Google Chrome.');
      return;
    }
    try {
      if (!navigator.mediaDevices?.getUserMedia) throw new Error('unsupported');
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      stream.getTracks().forEach((track) => track.stop());
    } catch (e) {
      setError('Нет доступа к микрофону. Разрешите доступ и попробуйте снова.');
      return;
    }
    runningRef.current = true;
    suspendedRef.current = false;
    setListening(true);
    setHeard('');
    setResponse('');
    setBlocked(null);
    setPhaseSafe('idle');
    try { window.speechSynthesis?.getVoices?.(); } catch (e) { /* noop */ }
    const recognition = buildRecognition();
    try { recognition.start(); } catch (e) { /* noop */ }
    emit({ who: 'system', text: 'Система активирована. Ожидаю слово «Джарвис»' });
  }, [emit, setPhaseSafe, supported]);

  const run = useCallback((text) => {
    execute(text);
  }, [execute]);

  const confirmBlocked = useCallback(() => {
    if (!blocked) return;
    try { window.open(blocked.url, '_blank'); } catch (e) { /* noop */ }
    setBlocked(null);
  }, [blocked]);

  const dismissBlocked = useCallback(() => setBlocked(null), []);

  return {
    supported,
    listening,
    phase,
    heard,
    response,
    error,
    blocked,
    start,
    stop,
    run,
    confirmBlocked,
    dismissBlocked,
  };
}