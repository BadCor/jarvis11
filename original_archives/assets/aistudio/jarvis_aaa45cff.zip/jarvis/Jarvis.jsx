import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { AlertTriangle } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import useJarvis from '@/hooks/useJarvis';
import { SYSTEM_COMMANDS } from '@/lib/voice';
import { useToast } from '@/components/ui/use-toast';
import HudHeader from '@/components/jarvis/HudHeader';
import TelemetryBar from '@/components/jarvis/TelemetryBar';
import VoiceOrb from '@/components/jarvis/VoiceOrb';
import OrbCaption from '@/components/jarvis/OrbCaption';
import Transcript from '@/components/jarvis/Transcript';
import CommandChips from '@/components/jarvis/CommandChips';
import BottomTray from '@/components/jarvis/BottomTray';
import ActivityLog from '@/components/jarvis/ActivityLog';
import PendingOpenCard from '@/components/jarvis/PendingOpenCard';
import CommandsDialog from '@/components/jarvis/CommandsDialog';

export default function Jarvis() {
  const [commands, setCommands] = useState([]);
  const [events, setEvents] = useState([]);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [journalOpen, setJournalOpen] = useState(true);
  const [now, setNow] = useState(() => new Date());
  const { toast } = useToast();

  useEffect(() => {
    const id = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(id);
  }, []);

  useEffect(() => {
    let alive = true;
    const load = async () => {
      try {
        const result = await base44.entities.VoiceCommand.list({ sort: '-created_date', limit: 200 });
        const items = Array.isArray(result) ? result : result?.items || [];
        if (alive) setCommands(items);
      } catch (e) {
        console.error('Не удалось загрузить команды', e);
      }
    };
    load();
    return () => { alive = false; };
  }, []);

  const pushEvent = useCallback((event) => {
    setEvents((prev) => [{ ...event, key: `${Date.now()}-${prev.length}` }, ...prev].slice(0, 40));
  }, []);

  const allCommands = useMemo(() => [...SYSTEM_COMMANDS, ...commands], [commands]);
  const jarvis = useJarvis({ commands: allCommands, onEvent: pushEvent });

  const handleAdd = async ({ phrase, url }) => {
    const fullUrl = /^[a-z]+:\/\//i.test(url) ? url : `https://${url}`;
    try {
      const created = await base44.entities.VoiceCommand.create({ phrase, url: fullUrl, kind: 'custom' });
      setCommands((prev) => [created, ...prev]);
      toast({ title: 'Команда добавлена', description: `«${phrase}» — ${fullUrl}` });
    } catch (e) {
      toast({ variant: 'destructive', title: 'Не удалось сохранить команду', description: 'Попробуйте ещё раз.' });
    }
  };

  const handleDelete = async (command) => {
    try {
      await base44.entities.VoiceCommand.delete(command.id);
      setCommands((prev) => prev.filter((item) => item.id !== command.id));
    } catch (e) {
      toast({ variant: 'destructive', title: 'Не удалось удалить команду' });
    }
  };

  const clock = now.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit', second: '2-digit' });

  return (
    <div className="relative min-h-screen w-full overflow-x-hidden bg-hud-bg font-body text-hud-text antialiased">
      <div aria-hidden className="pointer-events-none fixed inset-0 -z-10 bg-hud-void">
        <div className="absolute left-1/2 top-[38%] h-[760px] w-[760px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-hud-accent/5 blur-[150px]" />
        <div className="absolute left-1/2 top-[24%] h-[460px] w-[460px] -translate-x-1/2 rounded-full bg-hud-tertiary/5 blur-[120px]" />
      </div>

      <HudHeader
        listening={jarvis.listening}
        clock={clock}
        commandCount={commands.length}
        journalOpen={journalOpen}
        onOpenCommands={() => setDialogOpen(true)}
        onToggleJournal={() => setJournalOpen((prev) => !prev)}
      />

      <main className="relative pt-16">
        <TelemetryBar phase={jarvis.phase} listening={jarvis.listening} />

        <section className="relative flex min-h-[540px] w-full flex-col items-center justify-center px-4 py-6">
          <VoiceOrb phase={jarvis.phase} onClick={() => (jarvis.listening ? jarvis.stop() : jarvis.start())} />
          <OrbCaption phase={jarvis.phase} />
          <Transcript phase={jarvis.phase} response={jarvis.response} heard={jarvis.heard} />
          <CommandChips onRun={jarvis.run} />

          <PendingOpenCard
            pending={jarvis.blocked}
            onOpen={jarvis.confirmBlocked}
            onDismiss={jarvis.dismissBlocked}
          />

          {jarvis.error && (
            <div className="mt-8 flex items-center gap-2 rounded-xl border border-hud-error/30 bg-hud-error/10 px-4 py-2.5 text-sm text-hud-error">
              <AlertTriangle className="h-4 w-4 shrink-0" />
              {jarvis.error}
            </div>
          )}
        </section>

        <BottomTray
          listening={jarvis.listening}
          phase={jarvis.phase}
          onToggle={() => (jarvis.listening ? jarvis.stop() : jarvis.start())}
          commandCount={commands.length}
          eventCount={events.length}
        />

        {journalOpen && (
          <div className="mx-auto w-full max-w-[1100px] px-6 pb-10 lg:px-10">
            <ActivityLog events={events} />
          </div>
        )}
      </main>

      <CommandsDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        commands={commands}
        onAdd={handleAdd}
        onDelete={handleDelete}
      />
    </div>
  );
}