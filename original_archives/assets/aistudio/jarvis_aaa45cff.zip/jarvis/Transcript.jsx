import React from 'react';
import { cn } from '@/lib/utils';

const HINT = {
  off: 'Микрофон выключен — нажмите «Активировать»',
  idle: 'Голосовой ассистент готов к исполнению системных задач',
  active: 'Слушаю команду',
  busy: 'Обрабатываю запрос',
};

export default function Transcript({ phase = 'off', response, heard }) {
  const headline = response || 'Нажмите на сферу или скажите «Джарвис»';
  const subscript = heard ? `Вы: «${heard}»` : HINT[phase] || HINT.off;

  return (
    <div className="mt-8 flex max-w-2xl flex-col items-center gap-2 px-4 text-center transition-all duration-500">
      <h1
        className={cn(
          'text-2xl font-light leading-tight tracking-[-0.015em] text-hud-text transition-all duration-500 sm:text-[32px]',
          phase === 'active' && 'text-hud-accent-dim',
        )}
        style={phase === 'active' ? { textShadow: '0 0 28px rgba(56,189,248,0.5)' } : undefined}
      >
        {headline}
      </h1>
      <p className="text-sm text-hud-muted/70">{subscript}</p>
    </div>
  );
}