import React from 'react';
import { Mic, Radio } from 'lucide-react';
import { cn } from '@/lib/utils';

const PILL = 'rounded-full px-4 py-1.5 text-[11px] font-medium uppercase tracking-[0.14em] transition-all duration-200';

export default function HudHeader({ listening, clock, commandCount, journalOpen, onOpenCommands, onToggleJournal }) {
  return (
    <header className="fixed inset-x-0 top-0 z-50 border-b border-hud-text/8 bg-hud-surface/65 backdrop-blur-2xl">
      <div className="mx-auto flex h-16 w-full max-w-[1500px] items-center justify-between gap-6 px-6 lg:px-10">
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-2.5">
            <span
              className={cn(
                'h-2.5 w-2.5 rounded-full transition-colors',
                listening ? 'animate-pulse bg-hud-accent shadow-[0_0_12px_rgba(56,189,248,0.7)]' : 'bg-hud-dim',
              )}
            />
            <span className="text-xs font-medium uppercase tracking-[0.18em] text-hud-text">Ядро Джарвис</span>
          </div>

          <div className="hidden h-4 w-px bg-hud-text/10 sm:block" />

          <div className="hidden items-center gap-4 text-[10px] font-semibold uppercase tracking-[0.14em] text-hud-muted sm:flex">
            <span className="flex items-center gap-1.5">
              <Radio className={cn('h-3.5 w-3.5', listening ? 'text-hud-accent' : 'text-hud-dim')} />
              {listening ? 'прослушивание' : 'тишина'}
            </span>
            <span className="font-mono tabular-nums text-hud-muted/70">{clock}</span>
          </div>
        </div>

        <nav className="hidden items-center gap-1 rounded-full bg-hud-surface-low/70 p-1 backdrop-blur-md md:flex">
          <span className={cn(PILL, 'bg-hud-accent/15 text-hud-accent-dim')}>Голос</span>
          <button
            type="button"
            onClick={onOpenCommands}
            className={cn(PILL, 'text-hud-muted hover:bg-hud-text/5 hover:text-hud-text')}
          >
            Команды · {commandCount}
          </button>
          <button
            type="button"
            onClick={onToggleJournal}
            className={cn(
              PILL,
              journalOpen ? 'bg-hud-text/8 text-hud-text' : 'text-hud-muted hover:bg-hud-text/5 hover:text-hud-text',
            )}
          >
            Журнал
          </button>
        </nav>

        <div
          className={cn(
            'flex items-center gap-2 rounded-full px-3 py-1.5 transition-colors',
            listening ? 'bg-hud-accent/10 text-hud-accent-dim' : 'bg-hud-text/5 text-hud-muted',
          )}
        >
          <Mic className="h-3.5 w-3.5" />
          <span className="hidden text-[10px] font-semibold uppercase tracking-[0.14em] lg:inline">
            {listening ? 'активен' : 'выключен'}
          </span>
        </div>
      </div>
    </header>
  );
}