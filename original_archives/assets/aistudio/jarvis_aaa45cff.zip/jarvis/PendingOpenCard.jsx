import React from 'react';
import { AlertTriangle, ExternalLink, X } from 'lucide-react';

/** Карточка действия: показывается, когда браузер заблокировал новую вкладку. */
export default function PendingOpenCard({ pending, onOpen, onDismiss }) {
  if (!pending) return null;

  return (
    <div className="mt-8 w-full max-w-md rounded-2xl border border-hud-text/8 bg-hud-surface/85 p-4 backdrop-blur-2xl">
      <div className="flex items-center gap-3">
        <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-hud-accent/15">
          <AlertTriangle className="h-5 w-5 text-hud-accent" />
        </span>
        <div className="min-w-0 flex-1">
          <div className="text-[10px] font-semibold uppercase tracking-[0.2em] text-hud-accent-dim">
            Вкладка заблокирована
          </div>
          <div className="truncate text-sm text-hud-text">
            Разрешите всплывающие окна — и Джарвис откроет сам
          </div>
        </div>
        <button
          type="button"
          onClick={onDismiss}
          aria-label="Скрыть"
          className="rounded-full p-1.5 text-hud-dim transition-colors hover:bg-hud-text/5 hover:text-hud-text"
        >
          <X className="h-4 w-4" />
        </button>
      </div>

      <button
        type="button"
        onClick={onOpen}
        className="mt-4 flex w-full items-center justify-center gap-2 rounded-full border border-hud-accent/40 bg-hud-accent/10 px-5 py-2.5 text-[11px] font-medium uppercase tracking-[0.16em] text-hud-accent-dim transition-colors hover:bg-hud-accent/20"
      >
        Открыть {pending.label}
        <ExternalLink className="h-3.5 w-3.5" />
      </button>
    </div>
  );
}