import React from 'react';
import { cn } from '@/lib/utils';

const CAPTIONS = {
  off: { text: 'ОФФЛАЙН', tone: 'text-hud-dim' },
  idle: { text: 'ОЖИДАНИЕ', tone: 'text-hud-muted' },
  active: { text: 'СЛУШАЮ ВАС', tone: 'text-hud-accent' },
  busy: { text: 'ВЫПОЛНЯЮ', tone: 'text-hud-accent-dim' },
};

const BARS = ['h-1.5', 'h-2.5', 'h-1', 'h-3', 'h-1.5'];

export default function OrbCaption({ phase = 'off' }) {
  const state = CAPTIONS[phase] || CAPTIONS.off;
  const dancing = phase !== 'off';

  return (
    <div className="pointer-events-none -mt-7 flex flex-col items-center gap-2">
      <span
        className={cn(
          'text-[10px] font-semibold uppercase tracking-[0.2em] transition-colors duration-500',
          state.tone,
        )}
      >
        {state.text}
      </span>
      <div className="flex h-3 items-center gap-1.5">
        {BARS.map((height, i) => (
          <span
            key={height + i}
            className={cn('w-0.5 rounded-full', height, dancing ? 'bg-hud-accent/70' : 'bg-hud-dim/60')}
            style={dancing ? { animation: `hud-bar ${0.9 + i * 0.12}s ease-in-out ${i * 0.1}s infinite` } : undefined}
          />
        ))}
      </div>
    </div>
  );
}