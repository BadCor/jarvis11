import React from 'react';
import { History, Mic, MicOff } from 'lucide-react';
import { cn } from '@/lib/utils';

const VU_BARS = ['h-2', 'h-3', 'h-1', 'h-2.5', 'h-1', 'h-1'];

export default function BottomTray({ listening, phase, onToggle, commandCount, eventCount }) {
  const dancing = phase !== 'off';

  return (
    <div className="mx-auto flex w-full max-w-[1500px] flex-col items-center justify-between gap-4 px-6 pb-8 pt-4 lg:flex-row lg:px-10">
      <div className="flex items-center gap-3 rounded-full bg-hud-surface-low/70 px-4 py-2 backdrop-blur-xl">
        <span className="flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-[0.14em] text-hud-accent-dim">
          <Mic className="h-3.5 w-3.5 text-hud-accent" />
          Микрофон
        </span>
        <span className="text-hud-dim">/</span>
        <div className="flex h-3 items-center gap-1">
          {VU_BARS.map((height, i) => (
            <span
              key={height + i}
              className={cn('w-1 rounded-full', height, dancing ? 'bg-hud-accent/80' : 'bg-hud-dim/60')}
              style={dancing ? { animation: `hud-bar ${0.8 + i * 0.1}s ease-in-out ${i * 0.08}s infinite` } : undefined}
            />
          ))}
        </div>
        <span className="text-[10px] uppercase tracking-[0.14em] text-hud-muted/70">Веб-речь • ru-RU</span>
      </div>

      <button
        type="button"
        onClick={onToggle}
        className={cn(
          'flex items-center gap-3 rounded-full border px-7 py-3 text-[11px] font-medium uppercase tracking-[0.18em] transition-all duration-300',
          listening
            ? 'border-hud-error/30 bg-hud-error/10 text-hud-error hover:bg-hud-error/20'
            : 'border-hud-accent/40 bg-hud-surface/70 text-hud-text hover:bg-hud-accent/15 hover:shadow-[0_0_32px_-8px_rgba(56,189,248,0.55)]',
        )}
      >
        <span className={cn('h-2 w-2 rounded-full', listening ? 'animate-pulse bg-hud-error' : 'bg-hud-accent')} />
        {listening ? <MicOff className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
        {listening ? 'Отключить' : 'Активировать'}
      </button>

      <div className="flex items-center gap-6 text-[10px] uppercase tracking-[0.14em] text-hud-muted">
        <span className="flex items-center gap-2">
          <span className="h-1.5 w-1.5 rounded-full bg-hud-accent" />
          Команд в базе:
          <b className="font-mono text-hud-text">{commandCount}</b>
        </span>
        <span className="flex items-center gap-2">
          <History className="h-3.5 w-3.5 text-hud-dim" />
          Событий:
          <b className="font-mono text-hud-text">{eventCount}</b>
        </span>
      </div>
    </div>
  );
}