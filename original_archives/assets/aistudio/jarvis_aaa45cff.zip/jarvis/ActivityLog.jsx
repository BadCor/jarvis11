import React from 'react';
import { History } from 'lucide-react';
import { cn } from '@/lib/utils';

const ROLES = {
  user: { label: 'ВЫ', tone: 'text-hud-accent' },
  jarvis: { label: 'ДЖАРВИС', tone: 'text-hud-accent-dim' },
  system: { label: 'СИСТЕМА', tone: 'text-hud-muted' },
};

export default function ActivityLog({ events = [], className = '' }) {
  return (
    <div className={cn('rounded-2xl border border-hud-text/8 bg-hud-void/60 p-5 backdrop-blur-2xl', className)}>
      <div className="mb-4 flex items-center justify-between">
        <span className="flex items-center gap-2 text-[10px] font-semibold uppercase tracking-[0.2em] text-hud-muted">
          <History className="h-3.5 w-3.5 text-hud-accent" />
          Журнал сеанса
        </span>
        <span className="font-mono text-[10px] text-hud-dim">{events.length}</span>
      </div>

      {events.length === 0 ? (
        <p className="text-sm leading-relaxed text-hud-muted/70">
          Пока тихо. Скажите «Джарвис» и произнесите команду — например «открой YouTube».
        </p>
      ) : (
        <ul className="grid max-h-40 gap-2 overflow-y-auto pr-1 md:grid-cols-2">
          {events.map((event) => {
            const role = ROLES[event.who] || ROLES.system;
            return (
              <li
                key={event.key}
                className="flex items-center gap-3 rounded-xl bg-hud-text/3 px-3 py-2"
              >
                <span className={cn('shrink-0 text-[10px] font-semibold uppercase tracking-[0.16em]', role.tone)}>
                  {role.label}
                </span>
                <span className="min-w-0 flex-1 truncate text-sm text-hud-text/85">{event.text}</span>
                {event.at instanceof Date && (
                  <span className="shrink-0 font-mono text-[10px] text-hud-dim">
                    {event.at.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' })}
                  </span>
                )}
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}